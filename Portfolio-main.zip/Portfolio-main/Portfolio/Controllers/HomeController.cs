using Microsoft.AspNetCore.Mvc;
using Portfolio.Models;
using System.Diagnostics;

namespace Portfolio.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult About()
        {
            return View();
        }
        public IActionResult Education()
        {
            var EduList = new List<Education>()
            {
                new Education
                {
                    Degree = "Bsc",
                    Institution ="Daffodil International University",
                    GroupOf = "Computer Science And Engineering",
                    PassingYear = "Ongoing",
                    Result ="Ongoing"
                },
                new Education
                {
                    Degree = "HSC",
                    Institution ="Boarder Guard Public School And College",
                    GroupOf = "Science",
                    PassingYear = "2022",
                    Result ="GPA - 5.00"

                },
                new Education
                {
                    Degree = "SSC",
                    Institution ="Boarder Guard Public School And College",
                    GroupOf = "Science",
                    PassingYear = "2020",
                    Result ="GPA - 5.00"

                }

            };
          
            return View(EduList);
        }
        public IActionResult Contract()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}

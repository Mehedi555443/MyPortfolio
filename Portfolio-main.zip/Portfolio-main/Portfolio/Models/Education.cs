﻿using System;
namespace Portfolio.Models
{
    public class Education
    {
        public string Degree { get; set; }
        public string Institution { get; set; }
        public string GroupOf { get; set; }
        public string PassingYear { get; set; }
        public string Result { get; set; }
    }
}

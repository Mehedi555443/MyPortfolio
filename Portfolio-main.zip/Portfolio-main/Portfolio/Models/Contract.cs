﻿namespace Portfolio.Models
{
    public class Contract
    {
        public string Location { get; set; }
        public string Phone { get; set; }
        public string Gmail { get; set; }
        public string Social {  get; set; }

    }
}
